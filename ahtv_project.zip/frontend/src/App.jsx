import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import MovieDetail from './pages/MovieDetail';
import PersonPage from './pages/PersonPage';
import Auth from './pages/Auth';
import Profile from './pages/Profile';
import Navbar from './components/Navbar';

export default function App(){
  return (
    <div className="min-h-screen bg-white text-black">
      <Navbar />
      <main className="p-6">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/movie/:id" element={<MovieDetail/>} />
          <Route path="/person/:id" element={<PersonPage/>} />
          <Route path="/auth" element={<Auth/>} />
          <Route path="/profile" element={<Profile/>} />
        </Routes>
      </main>
    </div>
  );
}
