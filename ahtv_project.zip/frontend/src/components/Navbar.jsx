import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar(){
  return (
    <header className="flex items-center justify-between px-8 py-4 border-b border-gray-100">
      <div className="text-2xl font-semibold">AHTV</div>
      <nav className="space-x-6">
        <Link to="/" className="hover:underline">Ana Sayfa</Link>
        <Link to="/profile" className="hover:underline">Profil</Link>
        <Link to="/auth" className="hover:underline">Üye Ol / Giriş</Link>
      </nav>
    </header>
  );
}
