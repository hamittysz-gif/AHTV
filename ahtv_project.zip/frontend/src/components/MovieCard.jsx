import React from 'react';
import { Link } from 'react-router-dom';

export default function MovieCard({ movie }){
  return (
    <Link to={`/movie/${movie.id}`}>
      <div className="rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-shadow">
        <img src={movie.posterUrl || 'https://via.placeholder.com/320x450'} alt={movie.title} className="w-full h-[450px] object-cover"/>
        <div className="p-3 bg-white">
          <h3 className="font-semibold text-lg">{movie.title}</h3>
          <p className="text-sm text-gray-600">{movie.year}</p>
        </div>
      </div>
    </Link>
  );
}
