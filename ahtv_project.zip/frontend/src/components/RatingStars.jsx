import React from 'react';

export default function RatingStars({ value = 0 }) {
  return (
    <div className="flex items-center">
      <span className="text-sm font-semibold mr-2">{value}/10</span>
      <div className="flex space-x-1">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className={`w-3 h-3 rounded ${i < value ? 'bg-black' : 'border border-gray-300'}`}></div>
        ))}
      </div>
    </div>
  );
}
