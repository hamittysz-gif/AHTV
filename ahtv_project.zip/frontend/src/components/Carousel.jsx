import React, { useRef } from 'react';
import MovieCard from './MovieCard';

export default function Carousel({ movies }){
  const ref = useRef();
  return (
    <div className="my-6">
      <div className="relative">
        <div ref={ref} className="flex overflow-x-auto gap-4 py-4 carousel-scroll snap-x snap-mandatory">
          {movies.map(m => (
            <div key={m.id} className="snap-start flex-shrink-0 w-[320px]">
              <MovieCard movie={m} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
