import React, { useEffect, useState } from 'react';
import API from '../api/api';
import Carousel from '../components/Carousel';

export default function Home(){
  const [movies, setMovies] = useState([]);
  useEffect(()=> {
    API.get('/movies').then(res=> setMovies(res.data)).catch(console.error);
  },[]);
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Öne Çıkanlar</h1>
      <Carousel movies={movies} />
      <section className="mt-8">
        <h2 className="text-2xl font-semibold mb-3">Önerilen Filmler</h2>
        <div className="grid grid-cols-3 gap-6">
          {movies.map(m=> (
            <div key={m.id}><img src={m.posterUrl || 'https://via.placeholder.com/300x450'} alt=""/></div>
          ))}
        </div>
      </section>
    </div>
  );
}
