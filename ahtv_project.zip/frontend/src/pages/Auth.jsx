import React, { useState } from 'react';
import API from '../api/api';
import { useNavigate } from 'react-router-dom';

export default function Auth(){
  const [email,setEmail] = useState('');
  const [pass,setPass] = useState('');
  const [name,setName] = useState('');
  const [mode,setMode] = useState('login');
  const nav = useNavigate();

  async function submit(e){
    e.preventDefault();
    try {
      if(mode==='register'){
        await API.post('/auth/register', { name, email, password: pass });
        alert('Kayıt oldu, giriş yapın.');
        setMode('login');
      } else {
        const res = await API.post('/auth/login', { email, password: pass });
        localStorage.setItem('ahtv_token', res.data.token);
        nav('/');
      }
    } catch(err){
      alert(err?.response?.data?.error || 'Hata');
    }
  }

  return (
    <div className="max-w-md mx-auto">
      <h2 className="text-2xl mb-4">{mode === 'login' ? 'Giriş Yap' : 'Üye Ol'}</h2>
      <form onSubmit={submit} className="flex flex-col gap-3">
        {mode === 'register' && <input placeholder="Ad" value={name} onChange={e=>setName(e.target.value)} className="p-2 border"/>}
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} className="p-2 border"/>
        <input placeholder="Parola" value={pass} onChange={e=>setPass(e.target.value)} type="password" className="p-2 border"/>
        <button className="px-4 py-2 bg-black text-white rounded">{mode==='login' ? 'Giriş' : 'Kayıt'}</button>
      </form>
      <button onClick={()=> setMode(mode==='login'? 'register': 'login')} className="mt-3 text-sm text-gray-600">
        {mode==='login' ? 'Üye değil misin? Kayıt ol' : 'Zaten hesabın var mı? Giriş yap'}
      </button>
    </div>
  );
}
