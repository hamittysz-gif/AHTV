import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import API from '../api/api';
import RatingStars from '../components/RatingStars';

export default function MovieDetail(){
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  useEffect(()=> {
    API.get(`/movies/${id}`).then(res => setMovie(res.data)).catch(console.error);
  }, [id]);

  if (!movie) return <div>Yükleniyor...</div>;
  const avg = movie.reviews?.length ? Math.round(movie.reviews.reduce((a,b)=>a+b.rating,0)/movie.reviews.length) : 0;
  return (
    <div className="max-w-4xl mx-auto flex gap-8">
      <img src={movie.posterUrl || 'https://via.placeholder.com/320x450'} className="w-80 h-[420px] object-cover rounded" alt={movie.title}/>
      <div>
        <h1 className="text-4xl font-bold mb-2">{movie.title}</h1>
        <p className="text-sm text-gray-600 mb-4">{movie.year} • Yönetmen: {movie.director ? movie.director.name : '—'}</p>
        <p className="mb-4">{movie.overview}</p>

        <div className="mb-4">
          <h3 className="font-semibold mb-1">Puanlama</h3>
          <RatingStars value={avg} />
        </div>

        <div className="mt-6">
          <button className="px-4 py-2 border border-black rounded">Yorum Yaz</button>
        </div>
      </div>
    </div>
  );
}
