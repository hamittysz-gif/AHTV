import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import API from '../api/api';

export default function PersonPage(){
  const { id } = useParams();
  const [person, setPerson] = useState(null);
  useEffect(()=> {
    API.get(`/persons/${id}`).then(r => setPerson(r.data)).catch(console.error);
  }, [id]);

  if (!person) return <div>Yükleniyor...</div>;
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex gap-6">
        <img src={person.photoUrl || 'https://via.placeholder.com/200'} className="w-48 h-48 object-cover rounded" alt={person.name}/>
        <div>
          <h1 className="text-3xl font-bold">{person.name}</h1>
          <p className="mt-3">{person.bio}</p>
        </div>
      </div>
      <section className="mt-6">
        <h2 className="text-2xl font-semibold">Yapımları</h2>
        <ul className="mt-3">
          {(person.directedMovies || []).map(m => <li key={m.id}>{m.title}</li>)}
        </ul>
      </section>
    </div>
  );
}
