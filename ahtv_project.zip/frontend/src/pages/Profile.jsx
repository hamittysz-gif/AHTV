import React from 'react';

export default function Profile(){
  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold">Profilim</h1>
      <p className="mt-4">Burada kullanıcının yorumları, puanları ve favorileri gösterilecek.</p>
    </div>
  );
}
