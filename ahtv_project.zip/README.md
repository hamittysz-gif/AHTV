# AHTV - Minimal working project (frontend + backend)

This archive contains a minimal, working AHTV project:
- Backend: Node.js + Express + Sequelize + SQLite
- Frontend: React + Vite + TailwindCSS (minimal)

Quick local run (requires device with Node.js — if using desktop):
- backend:
  cd backend
  npm install
  cp .env.example .env
  node seed.js
  npm run dev

- frontend:
  cd frontend
  npm install
  npm run dev

NOTE: For mobile-only users, you can upload this repo to GitHub using your phone browser,
then deploy frontend to Vercel and backend to Render as previously instructed in chat.
