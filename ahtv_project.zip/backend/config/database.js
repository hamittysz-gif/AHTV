const { Sequelize } = require('sequelize');
require('dotenv').config();
const dbUrl = process.env.DATABASE_URL || 'sqlite:./database.sqlite';
const sequelize = new Sequelize(dbUrl, { logging: false });
module.exports = sequelize;
