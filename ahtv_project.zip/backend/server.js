const express = require('express');
const cors = require('cors');
require('dotenv').config();
const { sequelize } = require('./models');
const authRoutes = require('./routes/auth');
const moviesRoutes = require('./routes/movies');
const personsRoutes = require('./routes/persons');
const reviewsRoutes = require('./routes/reviews');

const app = express();
const corsOptions = {
  origin: process.env.FRONTEND_URL || '*'
};
app.use(cors(corsOptions));
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/movies', moviesRoutes);
app.use('/api/persons', personsRoutes);
app.use('/api/reviews', reviewsRoutes);

const PORT = process.env.PORT || 4000;
sequelize.sync().then(() => {
  app.listen(PORT, () => console.log(`Backend listening ${PORT}`));
}).catch(err => console.error(err));
