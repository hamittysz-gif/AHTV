const express = require('express');
const { Review } = require('../models');
const auth = require('../middleware/auth');
const router = express.Router();

router.post('/', auth, async (req, res) => {
  const { movieId, rating, comment } = req.body;
  if (rating < 1 || rating > 10) return res.status(400).json({ error: 'Rating 1..10' });
  const review = await Review.create({ movieId, rating, comment, userId: req.user.id });
  res.json(review);
});

router.get('/movie/:movieId', async (req, res) => {
  const reviews = await Review.findAll({ where: { movieId: req.params.movieId }});
  res.json(reviews);
});

module.exports = router;
