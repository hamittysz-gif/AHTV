const express = require('express');
const { Person, Movie } = require('../models');
const router = express.Router();

router.get('/', async (req, res) => {
  const people = await Person.findAll();
  res.json(people);
});

router.get('/:id', async (req, res) => {
  const person = await Person.findByPk(req.params.id, { include: [{ model: Movie, as: 'directedMovies' }]});
  if (!person) return res.status(404).json({ error: 'Not found' });
  res.json(person);
});

module.exports = router;
