const express = require('express');
const { Movie, Person, Review } = require('../models');
const auth = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req, res) => {
  const movies = await Movie.findAll({ include: [{ model: Review }, { model: Person, as: 'director' }]});
  res.json(movies);
});

router.get('/:id', async (req, res) => {
  const movie = await Movie.findByPk(req.params.id, { include: [ { model: Review }, { model: Person, as: 'director' } ]});
  if (!movie) return res.status(404).json({ error: 'Not found' });
  res.json(movie);
});

router.post('/', auth, async (req, res) => {
  const { title, overview, posterUrl, year, directorId } = req.body;
  const movie = await Movie.create({ title, overview, posterUrl, year, directorId });
  res.json(movie);
});

module.exports = router;
