const { DataTypes, Model } = require('sequelize');
const sequelize = require('../config/database');

class Person extends Model {}
Person.init({
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING, allowNull: false },
  bio: { type: DataTypes.TEXT },
  photoUrl: { type: DataTypes.STRING }
}, { sequelize, modelName: 'person' });

module.exports = Person;
