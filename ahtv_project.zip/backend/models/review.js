const { DataTypes, Model } = require('sequelize');
const sequelize = require('../config/database');

class Review extends Model {}
Review.init({
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  rating: { type: DataTypes.INTEGER, allowNull: false },
  comment: { type: DataTypes.TEXT },
  userId: { type: DataTypes.INTEGER, allowNull: false },
  movieId: { type: DataTypes.INTEGER, allowNull: false }
}, { sequelize, modelName: 'review' });

module.exports = Review;
