const sequelize = require('../config/database');
const User = require('./user');
const Movie = require('./movie');
const Person = require('./person');
const Review = require('./review');

// relations
User.hasMany(Review, { foreignKey: 'userId' });
Review.belongsTo(User, { foreignKey: 'userId' });

Movie.hasMany(Review, { foreignKey: 'movieId' });
Review.belongsTo(Movie, { foreignKey: 'movieId' });

Person.hasMany(Movie, { foreignKey: 'directorId', as: 'directedMovies' });
Movie.belongsTo(Person, { foreignKey: 'directorId', as: 'director' });

module.exports = { sequelize, User, Movie, Person, Review };
