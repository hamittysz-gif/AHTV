const { DataTypes, Model } = require('sequelize');
const sequelize = require('../config/database');

class Movie extends Model {}
Movie.init({
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  title: { type: DataTypes.STRING, allowNull: false },
  overview: { type: DataTypes.TEXT },
  posterUrl: { type: DataTypes.STRING },
  year: { type: DataTypes.INTEGER },
  directorId: { type: DataTypes.INTEGER, allowNull: true }
}, { sequelize, modelName: 'movie' });

module.exports = Movie;
