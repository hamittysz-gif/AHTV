const { sequelize, User, Movie, Person } = require('./models');
const bcrypt = require('bcrypt');

async function seed() {
  await sequelize.sync({ force: true });
  const pass = await bcrypt.hash('password', 10);
  await User.create({ name: 'Demo User', email: 'demo@ahtv.local', passwordHash: pass });

  const director = await Person.create({
    name: 'Sherren Lee',
    bio: 'Sherren Lee — director biography placeholder.',
    photoUrl: ''
  });

  await Movie.create({
    title: 'Float',
    overview: `Waverly (Andrea Bang) uzun süredir planladığı tıbbi uzmanlık programına ...`,
    posterUrl: 'https://i.imgur.com/YourPoster.png',
    year: 2023,
    directorId: director.id
  });

  console.log('Seed complete');
  process.exit();
}

seed();
